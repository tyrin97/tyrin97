﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private double j;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int first = int.Parse(textBox1.Text);
            int last = int.Parse(textBox2.Text);
            bool isprime = true;
            double sqrtRoot = Math.Sqrt(j);
            {


                if (first < 2)
                {
                    MessageBox.Show("Invalid Number, try again.");

                }
                else
                {
                    for (int i = first; i < last; i++)
                    {
                        for (int j = first; j < last; j++)
                        {
                            if (i != j && i % j == 0)
                            {
                                isprime = false;
                                break;
                            }
                        }
                        if (isprime)
                        {
                            listBox1.Items.Add(i);
                        }
                        isprime = true;
                    }
                }
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
